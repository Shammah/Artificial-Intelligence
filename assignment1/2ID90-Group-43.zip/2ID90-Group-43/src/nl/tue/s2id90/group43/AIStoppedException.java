package nl.tue.s2id90.group43;

/**
 *
 * This exception gets thrown when the program wants to stop the AI algorithm.
 */
public class AIStoppedException extends Exception {

    public AIStoppedException() {
    }

}
